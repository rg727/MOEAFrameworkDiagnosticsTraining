#This script takes all of the metric files (either seeds or parameters)
#and cuts them to have the same number of rows so that they can be averaged
#either by parameter or seed or both 
setwd("C:/Users/Rohini/Box Sync/MOEAFramework_Group/metrics/")

SEEDS = 10
PARAMS = 10

row_lengths = data.frame(matrix(0, ncol = SEEDS, nrow = PARAMS))

#First combine all seeds of 1 parameterization 

for (i in 1:PARAMS){
  for (j in 1:SEEDS){
    df = read.delim(paste0("NSGAII_lake_S",j,"_P",i,".txt"), sep=" ") 
    names(df)[1]<-"Hypervolume"
    row_lengths[i,j] = dim(df)[1]
    filename=paste0("NSGAII_lake_S",j,"_P",i,".txt")
    assign(paste0(filename),df)
  }
}

#Find minimum value of matrix to determine the min number of rows to cut off 

final_row_length = min(row_lengths)

for (i in 1:PARAMS){
  for (j in 1:SEEDS){
    df = read.delim(paste0("NSGAII_lake_S",j,"_P",i,".txt"), sep=" ",nrows=final_row_length) 
    names(df)[1]<-"#Hypervolume"
    filename=paste0("NSGAII_lake_S",j,"_P",i,".txt")
    setwd("C:/Users/Rohini/Box Sync/MOEAFramework_Group/metrics/Cut_Files/")
    write.table(df, file = filename, sep = " ", row.names = FALSE, col.names=TRUE, quote=FALSE)
    setwd("C:/Users/Rohini/Box Sync/MOEAFramework_Group/metrics/")
  }
}


